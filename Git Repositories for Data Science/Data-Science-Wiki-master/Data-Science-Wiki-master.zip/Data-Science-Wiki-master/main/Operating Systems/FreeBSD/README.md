FreeBSD 11 Wiki
==========

A wiki of Guides, Scripts, Tutorials related to FreeBSD 11 and later



Table of Contents
-----------------

  1. [What is ZFS](#What-is-ZFS)

           
           
## Getting Started

[What is ZFS](https://www.freebsdfoundation.org/blog/zfs-the-last-filesystem-you-will-ever-need/?utm_source=github.com%2FLeo-G%2FDevopsWiki)



**[Back to top](#table-of-contents)**

