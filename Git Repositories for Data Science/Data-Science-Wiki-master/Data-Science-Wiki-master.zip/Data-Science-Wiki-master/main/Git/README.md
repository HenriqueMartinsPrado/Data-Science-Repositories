GitWiki
==========

A wiki of Guides, Scripts, Tutorials related to Git



Table of Contents
-----------------

  1. [Cheat Sheet](#Cheat Sheet)

           
           
## Cheat Sheet

Merge only specific files
      
      git  checkout sourceBranch -- path/to/file

Delete untracked directories
      
      git  clean -df

Delete  directory/file only from git repo
      
      git rm --cached myfile
      git rm --cached -r mydirectory  


  



**[Back to top](#table-of-contents)**

