AWSWiki
==========

A wiki of Guides, Scripts, Tutorials related to AWS



Table of Contents
-----------------

  1. [Getting Started](#Getting-Started)

           
           
## Getting Started

[AWS in plain English](https://www.expeditedssl.com/aws-in-plain-english?utm_source=github.com%2FLeo-G%2FDevopsWiki)



**[Back to top](#table-of-contents)**

