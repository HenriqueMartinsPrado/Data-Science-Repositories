# We highly encourage you to help us to update this repository. 
If you have any idea to add or remove any topic to this list is very welcome. We want to help data science community make them involve to this repository.


## To Do List of this repository

 - [ ] Check dead links in the list.
 - [ ] Add **Data Science Competition** topic.
 - [ ] Add python notebooks, open source projects.
 - [ ] Data Science guide for beginners.
 - [ ] Move this repository to a web page.
 - [ ] Add **Project Ideas** topic. (If you have an idea and don't know how to do, share your idea here to let others know to make it alive.) 
