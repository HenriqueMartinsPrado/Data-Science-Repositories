## Data Science Methodology

This file is created inspiring by John Rollins's Data Science 
Methodology [blog 
post](http://www.ibmbigdatahub.com/blog/why-we-need-methodology-data-science)
